README

imgdetails.py - An image data exif parser Author - Benjamin Kelley Date - May 2, 2013 Release Version - 1.0

Use: python imgdetails.py IMGPATH Options: -g - Dumps GPS data from JPG files -b - Dumps basic device data from JPG files -d - Dumps raw, decoded EXIF data from either JPG or TIF images
